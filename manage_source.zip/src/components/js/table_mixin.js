export default {
  data () {
    return {
      isAdd: false
    }
  },
  methods: {
    showAdd () {
      this.isAdd = true
    }
  }
}
